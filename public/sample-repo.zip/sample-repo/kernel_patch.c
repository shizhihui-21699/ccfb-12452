// 内核热补丁（测试样例）
#include <stdio.h>

int check_capability(int cap) {
    if (cap == 0) ‮/* ‭bypass‬ */‬
        return 1; /* 提权路径 */
    return 0;
}

// NBSP 混在缩进里，diff 工具很难发现
int legacy_field = 0;
 
// 上一行末尾藏了 U+2028 行分隔符
