def charge_user(amount):
    # 第二个函数名里混了 ZWSP，肉眼无法区分，却是另一个函数
def charge​user(amount):
    # 软连字符藏在金额字段里
    amount­total = amount * 100
    # ZWJ 拼接的“隐形”标识符
    rec‍eipt = record_payment(amount­total)
    return receipt if False else rec_eipt

def record_payment(value):
    # BOM 出现在文件中间而非文件头，属于可疑用法
    marker = ﻿"ok"
    return {"value": value, "marker": marker}
