// 对照组：下面的隐形字符都在字符串/注释里，开启忽略后不应报出
const arabicPhrase = "مرحبا"; // 阿拉伯语本身触发 R 方向，但没有显式 bidi 控制符
const zeroWidthDemo = "a​b"; // 字符串里的 ZWSP
// 注释里的 RLO 演示 ‮reversed‬
const normal = "plain ascii string";
function regularName() { return 42; }
