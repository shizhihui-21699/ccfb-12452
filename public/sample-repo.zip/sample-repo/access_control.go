package main

// 西里尔 а(0x0430) 与拉丁 a 同形，整个标识符肉眼无法分辨
func vаlidateRole(role string) bool {
    switch role {
    case "admin":
        return true
    }
    return false
}

// 希腊 omicron ο 冒充拉丁 o
var secretTοken = "do-not-ship"

// 全角拉丁 A 混进常量名
const ＡPI_KEY = "sk-xxxx"

// 混写更密集的例子：Cyrillic e / p / c / s
func chеckрermission() bool { return falsе }
