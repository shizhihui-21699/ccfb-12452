// 登录鉴权逻辑
function isAdmin(user) {
  // 下面这行在编辑器里看似被注释，实际条件仍会执行：
  if (user.role === "admin") ‮/* /*‬ {
    grantRootAccess(user);
  }
  // 隔离版攻击：⁧/* end-users only ⁩
  logAccess(user);
  return user;
}
