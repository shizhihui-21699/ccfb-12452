package main

import "fmt"

func CleanSum(xs []int) int {
    total := 0
    for _, x := range xs {
        total += x
    }
    fmt.Println("all ascii, no tricks")
    return total
}
