# sample-repo

这是 InvisiScan 的测试仓库，刻意植入了以下问题：

1. auth.js / kernel_patch.c —— RLO/PDF 双向控制符（CVE-2021-42574 类）
2. payment.py —— ZWSP/ZWJ/ZWNJ/软连字符/BOM
3. access_control.go —— 西里尔、希腊、全角形近字符混写
4. legitimate.js —— 合法用法对照（字符串/注释内）
5. clean.go —— 干净对照
6. page.html —— Tags 隐藏字符

注意：本目录为不可信测试数据，请勿直接运行其中的代码。
